"""CSCA08 Fall 2023 Assignment 1.

This code is provided solely for the personal and private use of
students taking the CSCA08 course at the University of
Toronto. Copying for purposes other than this use is expressly
prohibited. All forms of distribution of this code, whether as given
or with any changes, are expressly prohibited.

All of the files in this directory and all subdirectories are:
Copyright (c) 2020-2023 Jacqueline Smith and Anya Tafliovich.

"""

from constants import (YR, MON, DAY, DEP, ARR, ROW, SEAT, FFN,
                       WINDOW, AISLE, MIDDLE, SA, SB, SC, SD, SE, SF)


def get_date(ticket: str) -> str:
    """
    Return the date of ticket 'ticket' in YYYYMMDD format.
    Precondition: ticket'ticket' is in valid format.
    >>> get_date('20230915YYZYEG12F')
    '20230915'
    >>> get_date('20240915YYZYEG12F1236')
    '20240915'
    """
    return get_year(ticket) + get_month(ticket) + get_day(ticket)


def get_year(ticket: str) -> str:
    """
    Return the year of ticket 'ticket'.
    
    Precondition:The input 'ticket' must be in a valid format.
    
    >>> get_year('20230915YYZYEG12F')
    '2023'
    >>> get_year('20240915YYZYEG12F1236')
    '2024'
    """
    return ticket[YR:YR + 4]


def get_month(ticket: str) -> str:
    """
    Return the month of ticket 'ticket'.
    Precondition: The input 'ticket' must be in a valid format.
    >>> get_month('20230915YYZYEG12F')
    '09'
    >>> get_month('20241215YYZYEG12F1236')
    '12'
    """
    return ticket[MON:MON + 2]


def get_day(ticket: str) -> str:
    """
    Return the day of ticket 'ticket'.
    Precondition:The input 'ticket' must be in a valid format.
    
    >>> get_day('20231221YYZYEG25F4442')
    '21'
    >>> get_day('20241215YYZYEG12F1236')
    '15'
    """
    return ticket[DAY:DAY + 2]


def visits_airport(ticket: str, airport: str) -> bool:
    """
    (Return True if and only if the departure or arrival airport mentioned in
    the 'ticket' is identical to the specified 'airport.
    The first parameter repersents the input ticket 'ticket'.
    The second parameter represents the input airport 'airport'.)
    Precondition:The input 'ticket' must be in a valid format.
    >>> visits_airport('20230915YYZYEG12F1236', 'YEG')
    True
    >>> visits_airport('20230915YEGYYZ12F1236', 'YEG')
    True
    >>> visits_airport('20230915YYZYEG12F1236', 'YVR')
    False
    """
    return (get_departure(ticket) == airport or get_arrival(ticket) == airport)


def get_departure(ticket: str) -> str:
    """
    Return the departure airport code on the given ticket 'ticket'.
    Precondition: the input ticket 'ticket' is valid.
    >>> get_departure('20231221YYZYEG25F4442')
    'YYZ'
    >>> get_departure('20241120YYZYEG20B4420')
    'YYZ'
    """
    return ticket[DEP:DEP + 3]


def get_arrival(ticket: str) -> str:
    """
    Return the arrival airport code on the given ticketn'ticket'.
    Precondition: the input ticket 'ticket' is valid.
    >>> get_arrival('20231221YYZYEG25F4442')
    'YEG'
    >>> get_arrival('20221120YYZLAS20B4420')
    'LAS'
    """
    return ticket[ARR:ARR + 3]


def get_seat_type(ticket: str) -> str:
    """
    (Return WINDOW, AISLE, or MIDDLE depending on the type of seat in
    ticket 'ticket'.)
    Precondition: 'ticket' is a valid ticket.
    >>> get_seat_type('20230915YYZYEG12F1236')
    'window'
    >>> get_seat_type('20230915YYZYEG08B')
    'middle'
    >>> get_seat_type('20230915YYZYEG12C1236')
    'aisle'
    """
    if get_seat(ticket) == SA or get_seat(ticket) == SF:
        return WINDOW
    if get_seat(ticket) == SB or get_seat(ticket) == SE:
        return MIDDLE
    return AISLE


def get_row(ticket: str) -> int:
    """
    Return the row number on the given ticket. 
    precondition: the input ticket'ticket' is valid.
    >>> get_row('20231221YYZYEG25F4442')
    25
    >>> get_row('20241020YYZYEG16D4420')
    16
    """
    return int(ticket[ROW:ROW + 2])


def get_seat(ticket: str) -> str:
    """
    Return the seat on the input ticket'ticket'.
    Precondition:The input 'ticket' must be in a valid format.
    >>> get_seat('20231221YYZYEG25F4442')
    'F'
    >>> get_seat('20241020YYZYEG25D4420')
    'D'
    """
    return ticket[SEAT:SEAT + 1]


def get_ffn(ticket: str) -> str:
    """
    Return the frequent flyer number on the given ticket. 
    Precondition:The input 'ticket' must be in a valid format.
    >>> get_ffn('20231221YYZYEG25F4442')
    '4442'
    >>> get_ffn('20231221YYZYEG25F')
    ''
    """
    return ticket[FFN:FFN + 4]


def is_valid_seat(ticket: str, first_row: int, last_row: int) -> bool:
    """
    (Return True if and only if this ticket has a valid seat. That is,
    if the seat row is between 'first_row' and 'last_row', inclusive,
    and the seat is SA, SB, SC, SD, SE, or SF.)
    Precondition: 'ticket' is in valid format.
    >>> is_valid_seat('20230915YYZYEG12F1236', 1, 30)
    True
    >>> is_valid_seat('20230915YYZYEG42F1236', 1, 30)
    False
    >>> is_valid_seat('20230915YYZYEG21Q1236', 1, 30)
    False
    """
    seats = [SA, SB, SC, SD, SE, SF]
    return (first_row <= get_row(ticket) <= last_row
            and get_seat(ticket) in seats)


def is_valid_ffn(ticket: str) -> bool:
    """
    Return True if and only if the frequent flyer number of 
    this ticket is valid.
    Precondition: 'ticket' is in valid format.
    >>> is_valid_ffn('20231221YYZYEG25F4442')
    True
    >>> is_valid_ffn('20231221YYZYEG25F')
    True
    >>> is_valid_ffn('20231221YYZYEG25F4451')
    False
    """
    if len(get_ffn(ticket)) == 4:
        return (int(ticket[FFN]) + int(ticket[FFN + 1])
                + int(ticket[FFN + 2])) % 10 == int(ticket[FFN + 3])
    return ticket[FFN:FFN + 4] == ''


def is_leap_year(ticket: str) -> bool:
    """
    Return a year is a leap year.
    The parameter is the input ticket 'ticket'.
    >>> is_leap_year('20231221YYZYEG25F4442')
    False
    >>> is_leap_year('20241221YYZYEG25F4442')
    True
    """
    year_type = int(get_year(ticket))
    if (year_type % 4 == 0 and year_type % 100 != 0) or (year_type % 400 == 0):
        return True
    return False


def is_valid_year(ticket: str) -> bool:
    """
    Return if the year in the ticket is a valid year.
    The parameter is the input ticket 'ticket'.
    >>> is_valid_year('20231221YYZYEG25F4442')
    True
    >>> is_valid_year('202A1221YYZYEG25F4442')
    False
    """
    return len(get_year(ticket)) == 4 and ticket[YR:YR + 4].isdigit()


def is_valid_date(ticket: str) -> bool:
    """
    Return True if and only if the date of this ticket is valid.
    Precondition: 'ticket' is in valid format.
    >>> is_valid_date('20231221YYZYEG25F4442')
    True
    >>> is_valid_date('20230230YYZYEG25F')
    False
    """
    large_months = [1, 3, 5, 7, 8, 10, 12]
    small_months = [4, 6, 9, 11]
    month_total = int(get_month(ticket))
    day_total = int(get_day(ticket))
    if not is_valid_year(ticket):
        return False
    if month_total in large_months:
        return 1 <= day_total <= 31
    if month_total in small_months:
        return 1 <= day_total <= 30
    if month_total == 2:
        if is_leap_year(ticket):
            return 1 <= day_total <= 29
        return 1 <= day_total <= 28
    return False


def adjacent(ticket1: str, ticket2: str) -> bool:
    """
    (Return True if any only if the seats in tickets 'ticket1' and
    'ticket2' are adjacent (next to each other).
    Seats located on opposite sides of an aisle are 
    not considered as being adjacent.)
    Precondition: ticket1 and ticket2 are in valid formats.
    >>> adjacent('20230915YYZYEG12D1236', '20230915YYZYEG12E1236')
    True
    >>> adjacent('20230915YYZYEG12B1236', '20230915YYZYEG12A1236')
    True
    >>> adjacent('20230915YYZYEG12C1236', '20230915YYZYEG12D1236')
    False
    >>> adjacent('20230915YYZYEG12A1236', '20230915YYZYEG11B1236')
    False
    """
    if get_row(ticket1) != get_row(ticket2):
        return False
    if get_seat(ticket1) == SB:
        return get_seat(ticket2) == SA or get_seat(ticket2) == SC
    if get_seat(ticket1) == SE:
        return get_seat(ticket2) == SD or get_seat(ticket2) == SF
    if get_seat(ticket2) == SB:
        return get_seat(ticket1) == SA or get_seat(ticket1) == SC
    if get_seat(ticket2) == SE:
        return get_seat(ticket1) == SD or get_seat(ticket1) == SF
    return False


def is_valid_ticket(ticket: str, first_row: int, last_row: int) -> bool:
    """ 
    (Return True if and only if the ticket and all of the ticket information
    on it satisfy valid conditions.
    The first parameter represents the input ticket'ticket'.
    The second parameter represents 'first_row'.
    The third parameter represents 'last_row'.)
    >>> is_valid_ticket('20230915YYZYEG32F1236',1,30)
    False
    >>> is_valid_ticket('20230915YYZYEG12F1236',1,30)
    True
    """
    return (is_valid_ticket_format(ticket) and is_valid_date(ticket)
            and is_valid_seat(ticket, first_row, last_row)
            and is_valid_ffn(ticket))


def is_valid_ticket_format(ticket: str) -> bool:
    """
    Return True if and only if ticket 'ticket' is in valid format:

    - year is 4 digits
    - months is 2 digits
    - day is 2 digits
    - departure is 3 letters
    - arrival is 3 letters
    - row is 2 digits
    - seat is a characters
    - frequent flyer number is either empty or 4 digits, and
      it is the last record in 'ticket'

    >>> is_valid_ticket_format('20241020YYZYEG12C1236')
    True
    >>> is_valid_ticket_format('20241020YYZYEG12C12361236')
    False
    >>> is_valid_ticket_format('ABC41020YYZYEG12C1236')
    False
    """
    return (FFN == 17
            and (len(ticket) == 17
                 or len(ticket) == 21 and ticket[FFN:FFN + 4].isdigit())
            and ticket[YR:YR + 4].isdigit()
            and ticket[MON:MON + 2].isdigit()
            and ticket[DAY:DAY + 2].isdigit()
            and ticket[DEP:DEP + 3].isalpha()
            and ticket[ARR:ARR + 3].isalpha()
            and ticket[ROW:ROW + 2].isdigit()
            and ticket[SEAT].isalpha())


def connecting(ticket1: str, ticket2: str) -> bool:
    """
    (Return True if and only if the two flights are linked: 
    the first flight arrives at the same airport 
    as the departure point of the second flight, 
    and both flights occur on the same dates.
    The first parameter represents the first given ticket 'ticket1'.
    The second parameter represents the second given ticket 'ticket2'.
    Precondition: the given tickets are in vaild format.)
    >>> connecting('20231221YYZYEG25F4442','20241020YYZYEG12C1236')
    False
    >>> connecting('20231221YEGYYZ25F4442','20231221YYZYEG25F4441')
    True
    """
    if get_date(ticket1) == get_date(ticket2):
        return get_arrival(ticket1) == get_departure(ticket2)
    return False


def behind(ticket1: str, ticket2: str) -> bool:
    """
    (Return True if and only if the seats on the two tickets 
    are situated directly one behind the other.
    The first parameter represents the first input ticket 'ticket1'.
    The second patameter represents the second input ticket 'ticket2'.
    Precondition:the given tickets are in vaild format.)
    >>> behind('20231221YYZYEG25F4442','20231221YYZYEG26F4442')
    True
    >>> behind('20241020YYZYEG25F4420','20241020YYZYEG28F4420')
    False
    """
    if get_seat(ticket1) == get_seat(ticket2):
        return abs(get_row(ticket1) - get_row(ticket2)) == 1
    return False


def change_seat(ticket: str, row: str, seat: str) -> str:
    """
    (Return a new ticket in the same format as the input ticket, 
    with matching departure, arrival, date, 
    and frequent flyer number as the input ticket, 
    and featuring updated seat information with the specified row and seat.
    The first parameter represents the first input ticket 'ticket'.
    The second parameter represents the input row 'row'.
    The third parameter represents the input seat 'seat'.
    Precondition: the ticket and the new seat information are valid.)
    >>> change_seat('20230915YYZYEG12F1236','24','A')
    '20230915YYZYEG24A1236'
    >>> change_seat('YYZLAS2009202416D4420','12','B')
    'YYZLAS2009202412B4420'
    """
    new_row = ticket[:ROW] + row + ticket[ROW + 2:]
    return new_row[:SEAT] + seat + new_row[SEAT + 1:]


def change_date(ticket: str, day: str, months: str, year: str) -> str:
    """ 
    (Return a new ticket in the same format as the input ticket, 
    maintaining the same departure, 
    arrival, seat information, and frequent flyer number as the input ticket, 
    while updating the date.
    The first parameter is the input ticket 'ticket'.
    The second parameter is the input day 'day'.
    The third parameter is the input months 'months'.
    The fourth parameter is the input year 'year'.
    Precondition: the ticket and the new seat information are valid.)
    >>> change_date('20230915YYZYEG12F1236','20','10','2024')
    '20241020YYZYEG12F1236'
    >>> change_date('20231221YYZYEG25F4442','10','11','2024')
    '20241110YYZYEG25F4442'
    """
    new_day = ticket[:DAY] + day + ticket[DAY + 2:]
    new_months = new_day[:MON] + months + new_day[MON + 2:]
    return new_months[:YR] + year + new_months[YR + 4:]


if __name__ == '__main__':
    import doctest
    doctest.testmod()
